"""
author: Ngo Van Uc
date: 27/09/2021
program: 01
solution:
    ...
"""
class Student(object):
    """class student"""
    def __init__(self, name):
        """constructor for name variable"""
        self.name = name

    def __str__(self):
        return "Student(%s)" % self.name

    def equalName(self, name):
        if self.name == name:
            return True
        else:
            return False

    def isName(self, name):
        if self.equalName(name):
            return True
        else:
            return False

    def orIsName(self, name):
        if self.name >= name:
            return True
        else:
            return False

    def getName(self):
        return self.name

    def setName(self, name):
        self.name = name
#
# """main of program"""
# student01 = Student("NguyenVanAn")
# student02 = Student("NgoVanVy")
# student03 = Student("NguyenVanAn")
# print(student01.getName()) #NguyenVanAn
# print(student01.equalName(student02.getName())) #False
# print(student01.orIsName(student03.getName())) #True
# print(student01.isName(student03.getName())) #True
#
# print(student01.orIsName(student02.getName())) #True



