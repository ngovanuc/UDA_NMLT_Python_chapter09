"""
author: Ngo Van Uc
date: 27/09/2021
program: 03
solution:
    ...
"""
class Account(object):
    """class Account"""
    def __init__(self, account, name, phone, balance = 0.0):
        """create a new ac"""
        self.account = account
        self.name = name
        self.phone = phone
        self.balance = balance

    def __str__(self):
        """toString to return a string that get information about account."""
        return "Account{acc = " + self.account +\
                ", name = " + self.name +\
                ", phone = " + self.phone +\
                ", balance = " + str(self.balance) + "}"


    def getAccount(self):
        """return account"""
        return self.account

    def getName(self):
        """return account name"""
        return self.name

    def getPhone(self):
        """return account phone"""
        return self.phone

    def getBalance(self):
        """return account balance"""
        return self.balance


    def setAccount(self, account):
        """set account"""
        self.account = account

    def setName(self, name):
        """set name"""
        self.name = name

    def setPhone(self, phone):
        """set phone"""
        self.phone = phone

    def setBalance(self, balance):
        """set balance"""
        self.balance = balance




