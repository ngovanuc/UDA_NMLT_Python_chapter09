"""
author: Ngo Van Uc
date: 27/09/2021
program: 02
solution:
    ...
"""
from NgoVanUc_53133_excercise_01 import Student

listStudent = []
listStudent.append(Student("NguyenVanAn"))
listStudent.append(Student("NgoBaoChau"))
listStudent.append(Student("HuynhQuangKhai"))
listStudent.append(Student("123"))

for i in range(len(listStudent)):
    print(listStudent[i].getName())

for i in range(0, len(listStudent)):
    for j in range(i, len(listStudent)):
        """i and j are Student object"""
        if listStudent[i].equalName(listStudent[j].getName()):
            """is name of student i equals to name of student j"""
            continue
        elif listStudent[i].orIsName(listStudent[j].getName()):
            """name of student i >= name of student j"""
            tg = listStudent[i]
            listStudent[i] = listStudent[j]
            listStudent[i] = tg

print('')
for i in range(len(listStudent)):
    print(listStudent[i].getName())