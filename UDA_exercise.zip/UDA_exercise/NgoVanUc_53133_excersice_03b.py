"""
author: NgoVanUc
date: 28/09/2021
program:
solution:
    ...
"""
from NgoVanUc_53133_exercise_03 import Account
class Bank(Account):
    """class Bank"""
    def __str__(self):
        return Account.__str__(self)

bank1 = Account("001", "NGOVANUC", "0852123123", 13.0)
print(bank1.__str__())